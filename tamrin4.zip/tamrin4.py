
class Node:
    def __init__(self, coefficients):
        self.coefficients = coefficients
        self.next = None
        self.prev = None

class PolynomialLinkedList:
    def __init__(self):
        self.head = None

    def add_polynomial(self, coefficients):
        new_node = Node(coefficients)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next is not None:
                current = current.next
            current.next = new_node
            new_node.prev = current

    def delete_polynomial(self, index):
        if self.head is None:
            raise Exception("No polynomials to delete.")
        if index == 1:
            self.head = self.head.next
            if self.head is not None:
                self.head.prev = None
        else:
            current = self.head
            count = 1
            while current is not None and count < index:
                current = current.next
                count += 1
            if current is None:
                raise Exception("Invalid index.")
            current.prev.next = current.next
            if current.next is not None:
                current.next.prev = current.prev

    def print_polynomials(self):
        if self.head is None:
            print("No polynomials to print.")
        else:
            current = self.head
            index = 1
            while current is not None:
                print(f"{index}. {current.coefficients}")
                current = current.next
                index += 1

    def add_polynomials(self, index1, index2):
        poly1 = self.get_polynomial(index1)
        poly2 = self.get_polynomial(index2)
        if poly1 is None or poly2 is None:
            raise Exception("Invalid index.")
        result = PolynomialLinkedList()
        result.add_polynomial([x + y for x, y in zip(poly1.coefficients, poly2.coefficients)])
        return result

    def multiply_polynomials(self, index1, index2):
        poly1 = self.get_polynomial(index1)
        poly2 = self.get_polynomial(index2)
        if poly1 is None or poly2 is None:
            raise Exception("Invalid index.")
        result = PolynomialLinkedList()
        result.add_polynomial([0] * (len(poly1.coefficients) + len(poly2.coefficients) - 1))
        current1 = poly1
        index2 = 0
        while current1 is not None:
            current2 = poly2
            index1 = 0
            while current2 is not None:
                result.add_polynomial([x + y for x, y in zip(current1.coefficients + [0] * index1, [0] * index2 + current2.coefficients)])
                current2 = current2.next
                index1 += 1
            current1 = current1.next
            index2 += 1
        return result

    def get_polynomial(self, index):
        if self.head is None:
            return None
        current = self.head
        count = 1
        while current is not None and count < index:
            current = current.next
            count += 1
        if current is None:
            return None
        return current.coefficients

polynomials = PolynomialLinkedList()

while True:
    print("Operations:")
    print("1. Add Polynomial")
    print("2. Delete Polynomial")
    print("3. Print Polynomial")
    print("4. Add Polynomials")
    print("5. Multiply Polynomials")
    print("6. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        coefficients = input("Enter the coefficients of the polynomial (space-separated): ").split()
        coefficients = list(map(int, coefficients))
        polynomials.add_polynomial(coefficients)
        print("Polynomial added successfully.")

    elif choice == 2:
        index = int(input("Enter the index of the polynomial to delete: "))
        polynomials.delete_polynomial(index)
        print("Polynomial deleted successfully.")

    elif choice == 3:
        polynomials.print_polynomials()

    elif choice == 4:
        index1 = int(input("Enter the index of the first polynomial to add: "))
        index2 = int(input("Enter the index of the second polynomial to add: "))
        result = polynomials.add_polynomials(index1, index2)
        result.print_polynomials()

    elif choice == 5:
        index1 = int(input("Enter the index of the first polynomial to multiply: "))
        index2 = int(input("Enter the index of the second polynomial to multiply: "))
        result = polynomials.multiply_polynomials(index1, index2)
        result.print_polynomials()

    elif choice == 6:
        print("Exiting the program...")
        break

    else:
        print("Invalid choice. Please try again.")



