def SelectionSort(lists):
    """
    مرتب سازی انتخابی که اسم و فامیلی را توی دیکشنری گداشته و بر اساس حروف الفبا مرتب کند
    
    """
    key_1 = "First Name"
    key_2 = "Last Name"
    x = len(lists)
    for i in range(x):
        smallest_index = i
        for j in range(i + 1, x):
            if lists[j][key_1] <= lists[smallest_index][key_1]:
                if lists[j][key_1] < lists[smallest_index][key_1]:
                    smallest_index = j
                elif (
                    lists[j][key_1] == lists[smallest_index][key_1]
                    and lists[j][key_2] < lists[smallest_index][key_2]
                ):
                    smallest_index = j
        lists[i], lists[smallest_index] = lists[smallest_index], lists[i]

    return lists
    
#اینجا لیست اسامی رو تعریف میکنم
lst = [{'First Name':'Ava','Last Name':'Danesh'},
    {'First Name':'Sara','Last Name':'Shirazi'},
    {'First Name':'Arefe','Last Name':'Sheikhali'},
    {'First Name':'Bahman','Last Name':'kiani'},
    {'First Name':'Diba','Last Name':'Zare'},
    {'First Name':'Jadi','Last Name':'Mirmirani'},
    {'First Name':'Kimia','Last Name':'Eskandari'},
    {'First Name':'Hoda','Last Name':'Sarkhosh'},
    {'First Name':'Shima','Last Name':'Shojaei'},
    ]
print(SelectionSort(lst))