
import matplotlib.pyplot as plt
import random
import timeit

# لیست اسم ها و فامیل ها
first_names = ['Ava', 'Sara', 'Arefe', 'Bahman', 'Diba', 'Jadi', 'Kimia', 'Hoda', 'Shima']
last_names = ['Danesh', 'Shirazi', 'Sheikhali', 'kiani', 'Zare', 'Mirmirani', 'Eskandari', 'Sarkhosh', 'Shojaei']

def randomize_names(size):
    data = [{'First Name': random.choice(first_names), 'Last Name': random.choice(last_names)} for _ in range(size)]
    return data

def selection_sort(names):
    for i in range(len(names)):
        min_index = i
        for j in range(i+1, len(names)):
            if names[j]['First Name'] < names[min_index]['First Name']:
                min_index = j
        names[i], names[min_index] = names[min_index], names[i]

# تولید داده‌های تصادفی با سایز‌های مختلف
sizes = range(10, 1001, 10)
execution_times = []

for size in sizes:
    data = randomize_names(size)
    # محاسبه زمان اجرای الگوریتم
    execution_time = timeit.timeit(lambda: selection_sort(data), number=1)
    execution_times.append(execution_time)

# رسم نمودار
plt.plot(sizes, execution_times)
plt.xlabel('Size of Data')
plt.ylabel('Execution Time (seconds)')
plt.title('Selection Sort Execution Time')
plt.show()